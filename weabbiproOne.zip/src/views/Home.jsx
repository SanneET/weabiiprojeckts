import Card from "../components/Card.jsx";
import "../styles/Card.css"; // Import your CSS file for styling

export default function Home() {
    return (
        <main>
            <section className="hero">
                <div className="hero-image">
                    <img src="../src/assets/Herobillede.png" alt="Hero" />
                </div>
            </section>
            <section>
                <h2 className="h2header">Styrk din digitale webløsning</h2>
                <p className="brødtekst">At få en hjemmeside kan føles som en stor mundfuld – men det behøver det ikke at være. Hos Wæbbi tager vi dig i hånden fra start til slut, så du får en løsning, der passer præcis til din virksomhed.</p>
                <p className="brødtekst">Du en personlig og gennemsigtig samarbejdspartner. Du får en fast kontaktperson, der guider dig gennem hele processen, så du altid ved, hvad der sker.</p>
            </section>
            <section>
                <h2 className="h2header">Hvad tilbyder vi?</h2>
                <p className="brødtekst">
                Vi rådgiver dig om alt fra webdesign (UI/UX), valg af CMS, opsætning af tracking og søgeoptimering til e-handel, kommunikation og digital markedsføring. Vores mål er at sikre, at du træffer de rigtige valg for din virksomheds online tilstedeværelse – uden teknisk jargon og med fokus på en løsning, der passer til dine behov. </p>
                
            </section>

            <section className="services">
        
                <div className="cards">
                    <Card title="Personlig rådgivning" description="Få personlig rådgivning om din webstrategi." />
                    <Card title="Webdesign UI/UX" description="Vi skaber brugervenlige og flotte designs." />
                    <Card title="CO2 reducerede løsninger" description="Mere bæredygtige websites." />
                    <Card title="Opsætning og tracking" description="Vi hjælper med SEO og tracking." />
                    <Card title="Kommunikation" description="Vi sørger for dit online brand skinner." />
                    <Card title="Søgeoptimering SEO" description="Bliv synlig på Google." />
                </div>
            </section>

            <section className="ekpertsystem">
                <h2>Mangler du stadig svar?</h2>
                <p>Spørg Wæbbi</p>
                <div className="maskotcontainer">
                    <img className="maskot" src="../src/assets/Maskot.jpg" alt="maskot" />
                </div>
                
            </section>
        </main>
    );
}