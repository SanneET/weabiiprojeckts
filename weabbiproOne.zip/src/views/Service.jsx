function Service() {
    return (
      <div>
        <h1>Service Side</h1>
        {/* Indhold her */}
      </div>
    );
  }
  
  export default Service;