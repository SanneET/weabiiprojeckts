export default function Service() {
    return <h1>værdi Side</h1>;
}