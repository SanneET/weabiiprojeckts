export default function Service() {
    return <h1>Service Side</h1>;
}