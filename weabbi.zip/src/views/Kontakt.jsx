export default function Service() {
    return <h1>kontakt Side</h1>;
}