import { Link } from "react-router-dom";
import { useState } from "react";
import "../styles/Header.css"; // Import CSS

export default function Header() {
    const [menuOpen, setMenuOpen] = useState(false);

    return (
        <header className="header">
            {/* Wæbbi logo i midten */}
            <div className="logo">
                <Link to="/">wæbbi</Link>
            </div>

            {/* Burger-menu knap */}
            <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)}>
                <svg viewBox="0 0 100 80" width="40" height="40">
                <rect width="100" height="15"></rect>
                <rect y="30" width="100" height="15"></rect>
                <rect y="60" width="100" height="15"></rect>
                </svg>
            </button>

            {/* Navigation */}
            <nav className={`nav ${menuOpen ? "open" : ""}`}>
                <Link to="../src/views/Service.jsx" onClick={() => setMenuOpen(false)}>Service</Link>
                <Link to="/vores-vaerdier" onClick={() => setMenuOpen(false)}>Vores værdier</Link>
                <Link to="/kontakt" onClick={() => setMenuOpen(false)}>Kontakt</Link>
            </nav>

            {/* Overlay bag navigation */}
            {menuOpen && <div className="overlay" onClick={() => setMenuOpen(false)}></div>}
        </header>
    );
}