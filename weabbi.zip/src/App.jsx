import "../src/styles/App.css";
import Service from "../src/views/Service";
import VoresVaerdier from "../src/views/VoresVaerdier";
import Kontakt from "../src/views/Kontakt";
import Home from "../src/views/Home";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import Layout from "../src/Layout";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      { index: true, element: <Home /> },
      { path: "service", element: <Service /> },
      { path: "vores-vaerdier", element: <VoresVaerdier /> },
      { path: "kontakt", element: <Kontakt /> }
    ],
  },
]);

function App() {
  return (
    <RouterProvider router={router} />
  );
}

export default App;
